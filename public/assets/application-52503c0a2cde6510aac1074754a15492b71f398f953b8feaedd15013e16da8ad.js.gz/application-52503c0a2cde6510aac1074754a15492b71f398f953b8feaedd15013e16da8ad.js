// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
// Portfolio controller
console.log("Portfolio controller loaded");
// This is the Sprockets manifest file
// It's separate from the importmap-powered application.js in app/javascript

;
