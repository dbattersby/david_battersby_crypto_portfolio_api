// Portfolio controller
console.log("Portfolio controller loaded");
