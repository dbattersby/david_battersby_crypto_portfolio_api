// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
