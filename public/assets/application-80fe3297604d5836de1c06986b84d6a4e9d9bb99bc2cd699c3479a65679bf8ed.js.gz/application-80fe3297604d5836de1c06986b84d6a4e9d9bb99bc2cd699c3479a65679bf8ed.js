// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
// This is a placeholder for Sprockets
// The actual controller functionality comes from importmap;
// This is the Sprockets manifest file
// It's separate from the importmap-powered application.js in app/javascript

;
